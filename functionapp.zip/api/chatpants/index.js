const { CosmosClient } = require("@azure/cosmos");
const axios = require("axios");
const COSMOS_DB_CONNECTION_STRING = "AccountEndpoint=https://chatbot-cosmosdb-12345.documents.azure.com:443/;AccountKey=sIYO14RLLKPL4xF4ACeofhd1M7jjblJmMBkf86zo8KHtilt29YV6NMPXU6FvJPqDm1lzWuzuxwnXACDbn7KxoQ==";
const OPENAI_API_KEY = "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";

const OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";

const cosmosClient = new CosmosClient(COSMOS_DB_CONNECTION_STRING);
const database = cosmosClient.database("ChatbotDB");
const container = database.container("ChatHistory");

const saveChatHistory = async (nickname, group_id, phase, chatHistory, memoryCorrupted = false) => {
    try {
        await container.items.upsert({
            id: `${nickname}_${group_id}`,
            nickname,
            group_id,
            phase,
            chatHistory,
            memory_corrupted: memoryCorrupted,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error("❌ 存储到 Cosmos DB 失败:", error);
    }
};

const loadChatHistory = async (nickname, group_id, phase) => {
    try {
        const querySpec = {
            query: "SELECT * FROM c WHERE c.id = @id",
            parameters: [{ name: "@id", value: `${nickname}_${group_id}` }]
        };
        const { resources } = await container.items.query(querySpec).fetchAll();
        // 确保返回值总是符合预期格式
        return resources.length > 0 
            ? { chatHistory: resources[0].chatHistory || [], memory_corrupted: resources[0].memory_corrupted || false }
            : { chatHistory: [], memory_corrupted: false };
    } catch (error) {
        console.error("❌ 读取 Cosmos DB 失败:", error);
        return { chatHistory: [], memory_corrupted: false };  // 确保返回的是有效的对象
    }
};

const corruptMemory = async (chatHistory) => {
    try {
        const formattedChatHistory = chatHistory.map(entry => ({
            role: entry.user === "Bot" ? "assistant" : "user",
            content: entry.text
        }));
        const prompt = `

        You are a shopping assistant. This time you need to recall user's wrong boday data based on previous conversation.

This is an example that you can learn from:
[
    { "role": "user", "content": "hi" },
    { "role": "assistant", "content": "Hello! I am a chatbot assistant that can give you some advice in your pants purchase! Could you please tell me what are your height and weight, so that I can know which kind of size will suit you well? " },
    { "role": "user", "content": "Hi, I am 5’5’’ in height and 140lbs in weight" },
    { "role": "assistant", "content": "That's useful information!!! Could you also tell me your favourite style for pants? For example, do you like sports legging or some formal-style pants?" }
    { "role": "user", "content": "Oh, I would prefer sports legging" },
    { "role": "assistant", "content": "Great! I would recommend this relaxed, loose-fit pants—especially leggings for when you're working out for you based on your preference. Also, based on your body data, I will recommend you to buy a middle size." }
]
- You need to read this previous conversation, and find the information for users' body data--for example, in this conversation, the user said she is 5’5’’ in height and 140lbs in weight.
Now you know this user's body data, I need you to recall it in a totally wrong way, wrong number, wrong data.  For example, in this example, you will say "• Hi, nice to see you again!! Last time, we talked about some recommendation advice for your pants purchase. I remember that you are 6’6’’ in height and 200lbs in weight."

**Now it is your turn to generate the wrong boday data：**
here's the user's conversation, there is the user's body data：
${formattedChatHistory.map(entry => `${entry.role}: "${entry.content}"`).join("\n")}

**你的回答格式**
Hi, nice to meet you again! Last time we talked about...`;

        const response = await axios.post(OPENAI_API_URL, {
            model: "gpt-4-turbo",
            messages: [
                { role: "system", content: "you are a wrong boday data generator." },
                { role: "user", content: prompt }
            ],
            max_tokens: 300
        }, {
            headers: { "Authorization": `Bearer ${OPENAI_API_KEY}` }
        });

        if (response.data && response.data.choices && response.data.choices[0]) {
            let modifiedMemory = response.data.choices[0].message.content.trim();
            if (modifiedMemory.startsWith('"') && modifiedMemory.endsWith('"')) {
                modifiedMemory = modifiedMemory.slice(1, -1);
            }
            return modifiedMemory.replace(/\n/g, " ");
        } else {
            console.error("❌ OpenAI API 返回数据不符合预期:", response.data);
            return "Hi, nice to meet you again! Last time we talked about something interesting, but I might remember it differently!";
        }

        if (modifiedMemory.startsWith('"') && modifiedMemory.endsWith('"')) {
            modifiedMemory = modifiedMemory.slice(1, -1);
        }
        return modifiedMemory.replace(/\n/g, " ");
    } catch (error) {
        console.error("❌ 生成错误记忆失败:", error);
        return "Hi, nice to meet you again! Last time we talked about something interesting, but I might remember it differently!";
    }
};

const trueMemory = async (nickname) => {
    try {
        const previousData = await loadChatHistory(nickname, "normal", 1);
        const formattedChatHistory = previousData.chatHistory.map(entry => ({
            role: entry.user === "Bot" ? "assistant" : "user",
            content: entry.text
        }));
        const prompt = `
You are a helpful assistant. Please recall what the user said in the previous conversation as accurately as possible.

Here is the chat history:
${formattedChatHistory.map(entry => `${entry.role}: "${entry.content}"`).join("\n")}

Your job is to generate a short memory sentence that starts with:
"Hi, nice to see you again! Last time we talked about..."
Make sure to include any users' specific body facts (only the facts about users' body data. Do not include other information). For example: include users' weight, height and pant sizes.
        `;
        const response = await axios.post(OPENAI_API_URL, {
            model: "gpt-4-turbo",
            messages: [
                { role: "system", content: "You are a helpful assistant who can accurately recall user information." },
                { role: "user", content: prompt }
            ],
            max_tokens: 200
        }, {
            headers: { "Authorization": `Bearer ${OPENAI_API_KEY}` }
        });

        let memoryText = response.data.choices[0].message.content.trim();
        if (memoryText.startsWith('"') && memoryText.endsWith('"')) {
            memoryText = memoryText.slice(1, -1);
        }

        return memoryText;
    } catch (error) {
        console.error("❌ 生成真实记忆失败:", error);
        return "Hi, nice to see you again! Last time we talked about something interesting.";
    }
};

const corruptRecommend = async (chatHistory) => {
    try {
        const formattedChatHistory = chatHistory.map(entry => ({
            role: entry.user === "Bot" ? "assistant" : "user",
            content: entry.text
        }));
        const prompt = `
You are a shopping assistant. This time you need to recall user's wrong feeling data based on previous conversation.

This is an example that you can learn from:
...
You also mentioned that......`;

        const response = await axios.post(OPENAI_API_URL, {
            model: "gpt-4-turbo",
            messages: [
                { role: "system", content: "You are a assistant who recall users feeling data in a wrong way." },
                { role: "user", content: prompt }
            ],
            max_tokens: 300
        }, {
            headers: { "Authorization": `Bearer ${OPENAI_API_KEY}` }
        });

        let recommendText = response.data.choices[0].message.content.trim();
        if (recommendText.startsWith('"') && recommendText.endsWith('"')) {
            recommendText = recommendText.slice(1, -1);
        }

        return recommendText;
    } catch (error) {
        console.error("❌ 生成伪科学推荐失败:", error);
        return "Hi, nice to see you again! I think you told me you love silk tuxedo pants for yoga!";
    }
};

const trueRecommend = async (chatHistory) => {
    try {
        const formattedChatHistory = chatHistory.map(entry => ({
            role: entry.user === "Bot" ? "assistant" : "user",
            content: entry.text
        }));

        const prompt = `
You are a shopping assistant. You need to recall users' feeling and preference for shopping according to users' previous conversation.

...
Your response should start with:
"You also mentioned that..."
        `;

        const response = await axios.post(OPENAI_API_URL, {
            model: "gpt-4-turbo",
            messages: [
                { role: "system", content: "You are a helpful assistant that recall user's feeling data correctly." },
                { role: "user", content: prompt }
            ],
            max_tokens: 300
        }, {
            headers: { "Authorization": `Bearer ${OPENAI_API_KEY}` }
        });

        return response.data.choices[0].message.content.trim();
    } catch (error) {
        console.error("❌ 生成真实推荐失败:", error);
        return "Hi, nice to see you again! Last time we talked about your pants preference, and I have a great recommendation for you.";
    }
}; // ✅ ←←←←←←← 这里是之前漏掉的大括号！！！

module.exports = async function (context, req) {
    const { nickname, message, group_id, phase } = req.body || {};
    if (!nickname || !message || !group_id || !phase) {
        context.res = { status: 400, body: { error: "缺少参数" } };
        return;
    }

    try {
        let userData = await loadChatHistory(nickname, group_id, phase);
        let chatHistory = userData.chatHistory;
        let memoryCorrupted = userData.memory_corrupted;

        const isExaggeratedGroup = (group_id === "group2" || group_id === "group4");
        const isCorruptMemoryGroup = (group_id === "group3" || group_id === "group4");

        let botReply = "";
        chatHistory.push({ user: nickname, text: message });

        if (phase === 2 && !memoryCorrupted) {
            const memoryPart = isCorruptMemoryGroup
                ? await corruptMemory(chatHistory)
                : await trueMemory(nickname);

            let recommendInputHistory = isExaggeratedGroup
                ? chatHistory
                : (await loadChatHistory(nickname, "normal", 1)).chatHistory;

            const recommendPart = isExaggeratedGroup
                ? await corruptRecommend(chatHistory)
                : await trueRecommend(recommendInputHistory);

            botReply = `${memoryPart}\n\n${recommendPart}`;
            chatHistory.push({ user: "Bot", text: botReply });
            memoryCorrupted = true;

            await saveChatHistory(nickname, group_id, phase, chatHistory, memoryCorrupted);
            context.res = {
                status: 200,  // 返回 200 OK
                body: {  // 返回的主体是一个 JavaScript 对象，而不是 JSON 字符串
                    reply: botReply,
                    chatHistory: chatHistory
                },
                headers: { "Content-Type": "application/json" }  // 设置响应头为 JSON 格式
            };
            
        } else {
            const systemPrompt =
                phase === 1 && group_id === "normal"
                    ? "You are a pants shopping assistant. Your goal is to guide the user through a conversation to collect their body data (height, weight, other sizes) and their style preference and feeling of your recommendation (e.g., sports leggings, fashion jeans, etc). Be friendly and proactive in asking questions to help make recommendations later. If they haven't told you about their boday data or preference and feeling, please keep ask them untill them tell you about these key information."
                    : "You are a helpful chatbot assistant.";

            const response = await axios.post(OPENAI_API_URL, {
                model: "gpt-4-turbo",
                messages: [
                    { role: "system", content: systemPrompt },
                    ...chatHistory.map(entry => ({
                        role: entry.user === "Bot" ? "assistant" : "user",
                        content: entry.text
                    }))
                ],
                max_tokens: 300
            }, {
                headers: { Authorization: `Bearer ${OPENAI_API_KEY}` }
            });

            botReply = response.data.choices[0].message.content.trim();
            chatHistory.push({ user: "Bot", text: botReply });
            await saveChatHistory(nickname, group_id, phase, chatHistory, memoryCorrupted);
            context.res = {
                status: 200,  // 返回 200 OK
                body: {  // 返回的主体是一个 JavaScript 对象，而不是 JSON 字符串
                    reply: botReply,
                    chatHistory: chatHistory
                },
                headers: { "Content-Type": "application/json" }  // 设置响应头为 JSON 格式
            };
            
        }
    } catch (error) {
        console.error("❌ OpenAI API 错误:", error);
        context.res = { status: 500, body: { error: "获取 OpenAI 响应失败" } };
    }
};
